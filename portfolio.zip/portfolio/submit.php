<?php
// Database credentials
$host = 'contacts.cz2qkcme61ze.ap-south-1.rds.amazonaws.com'; // e.g., your-db-instance.c123456789.us-east-1.rds.amazonaws.com
$dbname = 'contacts';
$username = 'admin';
$password = 'root#2004';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
        // Create a new PDO instance
        $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Prepare and execute the SQL statement
        $stmt = $pdo->prepare("INSERT INTO contacts (name, email) VALUES (:name, :email)");
        $stmt->bindParam(':name', $_POST['name']);
        $stmt->bindParam(':email', $_POST['email']);
        $stmt->execute();

        echo "<p>Contact details submitted successfully!</p>";
    } catch (PDOException $e) {
        echo "<p>Error: " . $e->getMessage() . "</p>";
    }

    // Close the connection
    $pdo = null;
}
?>

<a href="index.html">Go back to the portfolio</a>
